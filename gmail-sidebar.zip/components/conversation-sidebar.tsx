"use client"

import { useState, useEffect } from "react"
import { X, Calendar, AlertCircle } from "lucide-react"
import { format } from "date-fns"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { cn } from "@/lib/utils"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Types for our custom fields
type FieldType = "dropdown" | "number" | "text" | "date"

interface CustomField {
  id: string
  name: string
  type: FieldType
  value: string | number | null
  options?: string[] // For dropdown fields
  mandatory: boolean
  inboxId: string
}

interface ConversationSidebarProps {
  conversationId: string
  inboxId: string
  onClose: () => void
}

export function ConversationSidebar({ conversationId, inboxId, onClose }: ConversationSidebarProps) {
  // Mock data for custom fields based on inbox
  const [customFields, setCustomFields] = useState<CustomField[]>([])
  const [isClosing, setIsClosing] = useState(false)
  const [validationError, setValidationError] = useState<string | null>(null)

  // Fetch custom fields for the current inbox
  useEffect(() => {
    // In a real app, this would be an API call
    const mockFields: CustomField[] = [
      {
        id: "field1",
        name: "Issue Category",
        type: "dropdown",
        value: null,
        options: ["Billing", "Technical", "Account", "Feature Request"],
        mandatory: true,
        inboxId: "inbox1",
      },
      {
        id: "field2",
        name: "Priority Level",
        type: "number",
        value: null,
        mandatory: true,
        inboxId: "inbox1",
      },
      {
        id: "field3",
        name: "Notes",
        type: "text",
        value: null,
        mandatory: false,
        inboxId: "inbox1",
      },
      {
        id: "field4",
        name: "Follow-up Date",
        type: "date",
        value: null,
        mandatory: false,
        inboxId: "inbox1",
      },
    ]

    // Filter fields for the current inbox
    setCustomFields(mockFields.filter((field) => field.inboxId === inboxId))
  }, [inboxId])

  // Auto-save function
  const handleFieldChange = (fieldId: string, value: string | number | null) => {
    setCustomFields((prev) => prev.map((field) => (field.id === fieldId ? { ...field, value } : field)))

    // In a real app, this would trigger an API call to save the value
    console.log(`Auto-saving field ${fieldId} with value:`, value)

    // Clear validation error if previously shown
    if (validationError) {
      setValidationError(null)
    }
  }

  // Check if all mandatory fields are filled
  const validateMandatoryFields = () => {
    const emptyMandatoryFields = customFields
      .filter((field) => field.mandatory && (field.value === null || field.value === ""))
      .map((field) => field.name)

    if (emptyMandatoryFields.length > 0) {
      setValidationError(`Please complete these required fields: ${emptyMandatoryFields.join(", ")}`)
      return false
    }

    return true
  }

  // Handle conversation closure
  const handleCloseConversation = () => {
    setIsClosing(true)

    if (validateMandatoryFields()) {
      // In a real app, this would be an API call to close the conversation
      console.log("Closing conversation with custom field values:", customFields)
      onClose()
    } else {
      setIsClosing(false)
    }
  }

  // Sort fields to show mandatory fields first
  const sortedFields = [...customFields].sort((a, b) => {
    if (a.mandatory && !b.mandatory) return -1
    if (!a.mandatory && b.mandatory) return 1
    return 0
  })

  return (
    <div className="fixed right-0 top-0 z-50 flex h-full w-80 flex-col border-l bg-background shadow-lg">
      <div className="flex items-center justify-between border-b p-4">
        <h2 className="text-lg font-semibold">Conversation Details</h2>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex-1 overflow-auto p-4">
        <div className="mb-6">
          <h3 className="mb-2 text-sm font-medium text-muted-foreground">Custom Fields</h3>
          <Separator className="mb-4" />

          {validationError && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{validationError}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-4">
            {sortedFields.map((field) => (
              <div key={field.id} className="space-y-2">
                <div className="flex items-center">
                  <label htmlFor={field.id} className="text-sm font-medium">
                    {field.name}
                    {field.mandatory && <span className="ml-1 text-destructive">*</span>}
                  </label>
                  {field.mandatory && (
                    <Badge variant="outline" className="ml-2 text-xs">
                      Required
                    </Badge>
                  )}
                </div>

                {field.type === "dropdown" && (
                  <Select
                    value={field.value?.toString() || ""}
                    onValueChange={(value) => handleFieldChange(field.id, value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select an option" />
                    </SelectTrigger>
                    <SelectContent>
                      {field.options?.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}

                {field.type === "number" && (
                  <Input
                    id={field.id}
                    type="number"
                    placeholder="Enter a number (e.g., 123)"
                    value={field.value?.toString() || ""}
                    onChange={(e) => {
                      const value = e.target.value
                      if (value === "" || /^\d{0,10}$/.test(value)) {
                        handleFieldChange(field.id, value === "" ? null : Number.parseInt(value))
                      }
                    }}
                    className="w-full"
                  />
                )}

                {field.type === "text" && (
                  <Textarea
                    id={field.id}
                    placeholder="Enter your text"
                    value={field.value?.toString() || ""}
                    onChange={(e) => {
                      const value = e.target.value
                      const wordCount = value.trim().split(/\s+/).length
                      if (value === "" || wordCount <= 1000) {
                        handleFieldChange(field.id, value)
                      }
                    }}
                    className="min-h-[100px] w-full"
                  />
                )}

                {field.type === "date" && (
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !field.value && "text-muted-foreground",
                        )}
                      >
                        <Calendar className="mr-2 h-4 w-4" />
                        {field.value ? (
                          format(new Date(field.value.toString()), "dd MMM yyyy")
                        ) : (
                          <span>12 Aug 1993</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarComponent
                        mode="single"
                        selected={field.value ? new Date(field.value.toString()) : undefined}
                        onSelect={(date) => handleFieldChange(field.id, date ? date.toISOString() : null)}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="mb-6">
          <h3 className="mb-2 text-sm font-medium text-muted-foreground">Activity History</h3>
          <Separator className="mb-4" />
          <div className="space-y-3 text-sm">
            <div className="rounded-md bg-muted p-3">
              <p className="font-medium">Issue Category updated to "Technical"</p>
              <p className="text-xs text-muted-foreground">by John Doe • 2 hours ago</p>
            </div>
            <div className="rounded-md bg-muted p-3">
              <p className="font-medium">Priority Level set to "3"</p>
              <p className="text-xs text-muted-foreground">by Jane Smith • 3 hours ago</p>
            </div>
          </div>
        </div>
      </div>

      <div className="border-t p-4">
        <Button className="w-full" onClick={handleCloseConversation} disabled={isClosing}>
          {isClosing ? "Validating..." : "Close Conversation"}
        </Button>
      </div>
    </div>
  )
}
