"use client"

import { useState } from "react"
import { Mail, Star, Clock, Trash, Tag, MoreHorizontal } from "lucide-react"

import { Button } from "@/components/ui/button"
import { ConversationSidebar } from "@/components/conversation-sidebar"
import { Avatar } from "@/components/ui/avatar"
import { AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

// Mock data for conversations
const conversations = [
  {
    id: "conv1",
    subject: "Question about subscription plan",
    sender: "John Smith",
    email: "john.smith@example.com",
    preview: "Hi there, I was wondering about upgrading my current subscription plan to...",
    time: "10:23 AM",
    read: false,
    inboxId: "inbox1",
  },
  {
    id: "conv2",
    subject: "Technical issue with login",
    sender: "Sarah Johnson",
    email: "sarah.j@example.com",
    preview: "I'm having trouble logging into my account. It keeps saying invalid credentials...",
    time: "Yesterday",
    read: true,
    inboxId: "inbox1",
  },
  {
    id: "conv3",
    subject: "Feature request: Dark mode",
    sender: "Michael Brown",
    email: "michael.b@example.com",
    preview: "I would love to see a dark mode option in the next update. It would really help...",
    time: "Jul 12",
    read: true,
    inboxId: "inbox1",
  },
  {
    id: "conv4",
    subject: "Billing question",
    sender: "Emily Davis",
    email: "emily.d@example.com",
    preview: "I noticed an extra charge on my last invoice. Could you please explain what this is for?",
    time: "Jul 10",
    read: true,
    inboxId: "inbox1",
  },
  {
    id: "conv5",
    subject: "Account verification",
    sender: "Robert Wilson",
    email: "robert.w@example.com",
    preview: "I haven't received my verification email yet. Could you please resend it?",
    time: "Jul 8",
    read: true,
    inboxId: "inbox1",
  },
]

export default function InboxPage() {
  const [selectedConversation, setSelectedConversation] = useState<string | null>(null)

  const handleConversationClick = (conversationId: string) => {
    setSelectedConversation(conversationId)
  }

  const handleCloseSidebar = () => {
    setSelectedConversation(null)
  }

  return (
    <div className="flex h-screen flex-col bg-background">
      {/* Gmail-like header */}
      <header className="flex h-16 items-center border-b px-4">
        <div className="flex items-center">
          <Mail className="mr-2 h-6 w-6" />
          <h1 className="text-xl font-bold">Gmail</h1>
        </div>
        <div className="mx-auto flex w-full max-w-2xl items-center justify-center">
          <div className="relative w-full">
            <input
              type="text"
              placeholder="Search mail"
              className="w-full rounded-full border bg-muted/30 px-4 py-2 pl-10 focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <span className="absolute left-3 top-2.5 text-muted-foreground">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.3-4.3" />
              </svg>
            </span>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <div className="hidden w-64 flex-shrink-0 border-r md:block">
          <div className="p-4">
            <Button className="w-full justify-start rounded-full px-6 py-6">
              <Mail className="mr-2 h-4 w-4" />
              Compose
            </Button>
          </div>
          <nav className="space-y-1 px-2">
            <a href="#" className="flex items-center rounded-full px-3 py-2 text-sm font-medium text-primary">
              <Mail className="mr-3 h-4 w-4" />
              Inbox
            </a>
            <a
              href="#"
              className="flex items-center rounded-full px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted"
            >
              <Star className="mr-3 h-4 w-4" />
              Starred
            </a>
            <a
              href="#"
              className="flex items-center rounded-full px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted"
            >
              <Clock className="mr-3 h-4 w-4" />
              Snoozed
            </a>
            <a
              href="#"
              className="flex items-center rounded-full px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted"
            >
              <Tag className="mr-3 h-4 w-4" />
              Important
            </a>
            <a
              href="#"
              className="flex items-center rounded-full px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted"
            >
              <Trash className="mr-3 h-4 w-4" />
              Trash
            </a>
          </nav>
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-auto">
          <div className="divide-y">
            {conversations.map((conversation) => (
              <div
                key={conversation.id}
                className={`flex cursor-pointer items-center px-4 py-2 hover:bg-muted/50 ${
                  selectedConversation === conversation.id ? "bg-muted/50" : ""
                } ${!conversation.read ? "font-semibold" : ""}`}
                onClick={() => handleConversationClick(conversation.id)}
              >
                <div className="mr-4 flex-shrink-0">
                  <Avatar>
                    <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={conversation.sender} />
                    <AvatarFallback>{conversation.sender.charAt(0)}</AvatarFallback>
                  </Avatar>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <p className="truncate">{conversation.sender}</p>
                    <p className="ml-2 flex-shrink-0 text-xs text-muted-foreground">{conversation.time}</p>
                  </div>
                  <p className="truncate text-sm font-medium">{conversation.subject}</p>
                  <p className="truncate text-sm text-muted-foreground">{conversation.preview}</p>
                </div>
                <div className="ml-4 flex flex-shrink-0 items-center">
                  {!conversation.read && <Badge variant="default" className="h-2 w-2 rounded-full p-0" />}
                  <Button variant="ghost" size="icon" className="ml-2">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Conversation sidebar */}
        {selectedConversation && (
          <ConversationSidebar conversationId={selectedConversation} inboxId="inbox1" onClose={handleCloseSidebar} />
        )}
      </div>
    </div>
  )
}
